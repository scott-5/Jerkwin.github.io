 molecular dynamics 
 $cntrl
  irest  = 0, ntx    = 1,
  ntb    = 2, ntp    = 1,
  nstlim = 50000,
  dt     = 0.001,
  ntpr   = 1000,
  vrand  = 500,
  npscal = 1,
  iwrap  = 1,
  ntt    = 1,
  nsnb   = 5,
  temp0  = 300.,
  cut    = 14.0,
  scee   = 1.2,
  ntf    = 2,
  ntc    = 2,
 $end

