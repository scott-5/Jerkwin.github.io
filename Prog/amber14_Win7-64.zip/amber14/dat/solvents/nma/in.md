 molecular dynamics 
 $cntrl
  irest  = 1, ntx    = 7,
  ntb    = 2, ntp    = 1,
  nstlim = 5,
  dt     = 0.001,
  ntpr   = 1000,
  ntt    = 1,
  iwrap  = 1,
  nsnb   = 5,
  temp0  = 373.,
  cut    =  8.0,
  scee   = 1.2,
  ntf    = 2,
  ntc    = 2,
 $end

